export const cloudName = "dddotdmjo";
export const apiKey = "572265482388332";
export const apiSecret = "rnjhXI6QKK7socPaKKjS1ndWNaY";