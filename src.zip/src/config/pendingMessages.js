// import { getFirestore, collection, doc, getDoc, deleteDoc, setDoc, arrayUnion } from 'firebase/firestore';

// const db = getFirestore();

// export const savePendingMessage = async (userId, message) => {
//   const pendingMessagesRef = doc(db, 'pendingMessages', userId);

//   await setDoc(pendingMessagesRef, {
//     messages: arrayUnion(message),
//   }, { merge: true });
// };

// export const getAndDeletePendingMessages = async (userId) => {
//   const pendingMessagesRef = doc(db, 'pendingMessages', userId);
//   const pendingMessagesSnapshot = await getDoc(pendingMessagesRef);

//   if (pendingMessagesSnapshot.exists()) {
//     const pendingMessages = pendingMessagesSnapshot.data().messages;

//     // Delete pending messages after retrieving
//     await deleteDoc(pendingMessagesRef);

//     return pendingMessages;
//   }

//   return [];
// };
