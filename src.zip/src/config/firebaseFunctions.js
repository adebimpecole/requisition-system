import {
    getFirestore,
    collection,
    query,
    where,
    addDoc,
    getDocs,
    doc,
    updateDoc,
  } from "firebase/firestore";

const db = getFirestore();

// Function to fetch data from Firestore
const fetchDataFromFirestore = async () => {
  try {
    const data = [];
    const querySnapshot = await db.collection('your_collection').get();
    querySnapshot.forEach((doc) => {
      data.push({ id: doc.id, ...doc.data() });
    });
    return data;
  } catch (error) {
    console.error('Error fetching data:', error);
    throw error;
  }
};

// Function to add data to Firestore
const addToFirestore = async (dataToAdd) => {
  try {
    await firestore.collection('your_collection').add(dataToAdd);
    console.log('Data added successfully');
  } catch (error) {
    console.error('Error adding data:', error);
    throw error;
  }
};

export { fetchDataFromFirestore, addToFirestore };
