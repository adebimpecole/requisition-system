
export const newRequest = async (reqId, userId) => {
    // Make an API call to the backend server
    const payload = {
        userId: userId,
        reqId: reqId
    };

    let theUser = 'TjQnE8rFM2fL6xfVqWU4IZjFU2Y2';

    fetch(`http://localhost:5000/users/${theUser}/pending`, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify(payload),
    })
    .then(response => {
        if (!response.ok) {('Something went wrong');
        }
        return response.json();
    })
    .then(data => {
        console.log('Request sent to backend successfully:', data);
    })
    .catch(error => {
        console.error('There was a problem sending the Request:', error);
    });
};

export const generateCustomId = (prefix, length) => {
  const characters =
    "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
  const charactersLength = characters.length;
  let customId = prefix;

  for (let i = 0; i < length; i++) {
    const randomIndex = Math.floor(Math.random() * charactersLength);
    customId += characters.charAt(randomIndex);
  }

  return customId;
}


export const fetchData = async (userId) => {
    // fetch(`/users/${userId}/pending`)
    //     .then((response) => {
    //         if (!response.ok) {
    //             throw new Error('Network response was not ok');
    //         }
    //         return response.json();
    //     })
    //     .then((data) => {
    //         // Handle the data retrieved (pending requests) for the logged-in user
    //         console.log('Pending requests:', data);
    //         // Update state or perform actions based on the retrieved data
    //     })
    //     .catch((error) => {
    //         console.error('There was a problem fetching pending requests:', error);
    //     });

}