import React, { useState, useEffect, useContext } from "react";
import { useNavigate } from "react-router-dom";

import "./Auth.sass";
import Nav from "./Nav";
import Example from "./dnd/example";

import { DndProvider } from "react-dnd";
import { HTML5Backend } from "react-dnd-html5-backend";

const Setup2 = () => {
  const navigate = useNavigate();

  const MoveOn = () => {
    navigate("/setup3");
  }
  return (
    <div className="auth">
      <div className="auth_background">
        <div className="nav">
          <Nav />
        </div>
      </div>
      <div className="auth_content">
        <div className="auth_section">
          <h2 className="page_header auths_header">
            Set Up Your Company Approvers
          </h2>
          <div className="add_section">
            <div className="add_title">
              Organize Approvers in the Approval Workflow
            </div>
            <div className="add_note">
              Kindly rearrange the approvers in the appropriate workflow or
              approval process sequence.
            </div>
            <div className="added my_added">
              <div className="added_approvers"> Approvers</div>
              <DndProvider backend={HTML5Backend}>
                <Example />
              </DndProvider>
            </div>
          </div>

          <div className="button_section">
            <div className="save_button" onClick={MoveOn}>Next </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Setup2;
