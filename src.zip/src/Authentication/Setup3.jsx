import React, { useState, useContext, useRef, useEffect } from "react";
import { NavLink, useNavigate } from "react-router-dom";

import {
  getFirestore,
  collection,
  query,
  where,
  getDocs,
  doc,
  addDoc,
  getDoc,
  updateDoc,
  arrayUnion,
  setDoc,
} from "firebase/firestore";

import "./Auth.sass";
import Nav from "./Nav";
import { Context } from "../Utilities/Context";

const Setup3 = () => {
  let { user, setuser, id, setid, errorMessage } = useContext(Context);

  const navigate = useNavigate();
  const db = getFirestore();

  const [approvers, setApprovers] = useState([]);
  const [selectedApprover, setSelectedApprover] = useState('');

  // get approvers
  useEffect(() => {
    const userCollectionRef = collection(db, "companies");
    const query4 = query(userCollectionRef, where("userId", "==", id));

    getDocs(query4)
      .then((querySnapshot) => {
        if (!querySnapshot.empty) {
          const userData = [];
          querySnapshot.forEach((doc) => {
            userData.push(doc.data());
          });
          setApprovers(userData[0].approvers);
        } else {
        }
      })
      .catch((error) => {
        console.error("Error getting user data:", error);
      });
  }, [id]);

  const handleApproverChange = (event) => {
    setSelectedApprover(event.target.value);
  };

  const MoveOn = async() => {
    console.log(selectedApprover)
    try {
      const userCollectionRef = collection(db, "companies");
      const query4 = query(userCollectionRef, where("userId", "==", id));

      const querySnapshot = await getDocs(query4);

      querySnapshot.forEach(async (doc) => {
        try {
          const docRef = doc.ref;

          await setDoc(docRef, { fundingAuthority: selectedApprover }, { merge: true });
        } catch (error) {
          console.error(
            "Error updating document in 'companies' collection:",
            error
          );
        }
      });
    } catch (error) {
      console.error("Error fetching data:", error);
    }
    navigate("/setup4");
  }
  return (
    <div className="auth">
      <div className="auth_background">
        <div className="nav">
          <Nav />
        </div>
      </div>
      <div className="auth_content">
        <div className="auth_section">
          <h2 className="page_header auths_header">
            Set Up Your Company Approvers
          </h2>
          <div className="add_section">
            <div className="add_title">
              Select Approvers with Funding Authority
            </div>
            <div className="add_note">
              Please carefully choose the approver(s) who hold funding authority
              within the specified workflow. This individual or group is
              responsible for approving requests related to financial
              allocations.
            </div>
            <div className="added my_added">
              <div className="added_approvers"> Approvers</div>
              <div className="the_approvers">
                {approvers.length > 0 ? (
                  <>
                    {approvers.map((approver, i) => (
                      <label key={i}>
                        <input type="radio" name="approver" value={approver} checked={selectedApprover === approver}
                onChange={handleApproverChange}/>
                        <span className="value">{approver}</span>
                      </label>
                    ))}
                  </>
                ) : (
                  <span>Loading...</span>
                )}
              </div>
            </div>
          </div>

          <div className="button_section">
            <div className="save_button" onClick={MoveOn}>Next </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Setup3;
