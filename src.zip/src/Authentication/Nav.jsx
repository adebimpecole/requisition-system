import React from 'react'
import Logo from '../LandingPage/Logo'
import "./Auth.sass"

const Nav = () => {
  return (
    <div className='auth_nav'>
      <Logo color="white"/>
    </div>
  )
}

export default Nav
